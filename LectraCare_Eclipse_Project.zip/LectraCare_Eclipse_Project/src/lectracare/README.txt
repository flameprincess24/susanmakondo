LECTRACARE - Eclipse Java Prototype

Purpose:
LectraCare is a simple university support system for recording student concerns
about lecturer teaching/communication/assessment/attendance and helping students
request appointments with lecturers.

Features:
1. Register students
2. Register lecturers
3. Submit concerns
4. Rule-based automatic recommendation
5. Book lecturer appointments
6. View records
7. Generate a summary report

ECLIPSE:
1. File > Import > Existing Projects into Workspace (if importing a project).
2. Or create a Java Project named LectraCare and copy the src/lectracare files into it.
3. Run Main.java as Java Application.

IMPORTANT:
This is the first prototype. It stores data in memory only. Closing the program
clears the data. A later version can use MySQL for permanent storage and JavaFX
or Swing for a graphical interface.

Recommendation engine:
- Teaching Method -> discuss teaching method / academic support
- Communication -> arrange a meeting
- Assessment -> review assessment / clarification
- Attendance -> discuss and escalate repeated issues
- Other -> discuss first and escalate if unresolved
