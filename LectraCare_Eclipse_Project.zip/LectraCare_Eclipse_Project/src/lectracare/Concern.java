package lectracare;

public class Concern {
    private int id;
    private String studentName;
    private String lecturerName;
    private String category;
    private String description;
    private String recommendation;

    public Concern(int id, String studentName, String lecturerName,
                   String category, String description) {
        this.id = id;
        this.studentName = studentName;
        this.lecturerName = lecturerName;
        this.category = category;
        this.description = description;
        this.recommendation = generateRecommendation();
    }

    private String generateRecommendation() {
        if (category.equalsIgnoreCase("Teaching Method")) {
            return "Discuss the teaching method with the lecturer and consider academic support.";
        } else if (category.equalsIgnoreCase("Communication")) {
            return "Arrange a meeting with the lecturer to discuss communication concerns.";
        } else if (category.equalsIgnoreCase("Assessment")) {
            return "Review the assessment method and request clarification from the lecturer.";
        } else if (category.equalsIgnoreCase("Attendance")) {
            return "Discuss the attendance concern with the lecturer and, if repeated, notify the department.";
        } else {
            return "Discuss the issue with the lecturer first and escalate if it remains unresolved.";
        }
    }

    public int getId() { return id; }
    public String getStudentName() { return studentName; }
    public String getLecturerName() { return lecturerName; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getRecommendation() { return recommendation; }

    public void displayConcern() {
        System.out.println("\n--- Concern " + id + " ---");
        System.out.println("Student: " + studentName);
        System.out.println("Lecturer: " + lecturerName);
        System.out.println("Category: " + category);
        System.out.println("Description: " + description);
        System.out.println("Recommended action: " + recommendation);
    }
}
