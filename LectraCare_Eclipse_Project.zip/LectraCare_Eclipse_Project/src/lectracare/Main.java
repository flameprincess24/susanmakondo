package lectracare;

import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static LectraCareSystem system = new LectraCareSystem();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            showMenu();
            int choice = readInt("Choose an option: ");

            switch (choice) {
                case 1: registerStudent(); break;
                case 2: registerLecturer(); break;
                case 3: submitConcern(); break;
                case 4: bookAppointment(); break;
                case 5: system.displayStudents(); break;
                case 6: system.displayLecturers(); break;
                case 7: system.displayConcerns(); break;
                case 8: system.displayAppointments(); break;
                case 9: system.generateReport(); break;
                case 10:
                    running = false;
                    System.out.println("\nThank you for using LectraCare.");
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1-10.");
            }
        }

        scanner.close();
    }

    private static void showMenu() {
        System.out.println("\n=================================");
        System.out.println("           LECTRACARE");
        System.out.println(" Lecturer Quality & Student Support");
        System.out.println("=================================");
        System.out.println("1. Register Student");
        System.out.println("2. Register Lecturer");
        System.out.println("3. Submit Concern");
        System.out.println("4. Book Lecturer Appointment");
        System.out.println("5. View Students");
        System.out.println("6. View Lecturers");
        System.out.println("7. View Concerns");
        System.out.println("8. View Appointments");
        System.out.println("9. Generate Report");
        System.out.println("10. Exit");
        System.out.println("=================================");
    }

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static void registerStudent() {
        int id = readInt("Enter student ID: ");
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        system.addStudent(new Student(id, name, email));
        System.out.println("Student registered successfully.");
    }

    private static void registerLecturer() {
        int id = readInt("Enter lecturer ID: ");
        System.out.print("Enter lecturer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter department: ");
        String department = scanner.nextLine();

        system.addLecturer(new Lecturer(id, name, department));
        System.out.println("Lecturer registered successfully.");
    }

    private static void submitConcern() {
        System.out.print("Enter student name: ");
        String student = scanner.nextLine();
        System.out.print("Enter lecturer name: ");
        String lecturer = scanner.nextLine();

        System.out.println("\nConcern category:");
        System.out.println("1. Teaching Method");
        System.out.println("2. Communication");
        System.out.println("3. Assessment");
        System.out.println("4. Attendance");
        System.out.println("5. Other");

        int categoryChoice = readInt("Choose category: ");
        String category;

        switch (categoryChoice) {
            case 1: category = "Teaching Method"; break;
            case 2: category = "Communication"; break;
            case 3: category = "Assessment"; break;
            case 4: category = "Attendance"; break;
            default: category = "Other";
        }

        System.out.print("Describe your concern: ");
        String description = scanner.nextLine();

        int id = getNextConcernId();
        Concern concern = new Concern(id, student, lecturer, category, description);
        system.addConcern(concern);

        System.out.println("\nConcern submitted successfully.");
        concern.displayConcern();
    }

    private static void bookAppointment() {
        System.out.print("Enter student name: ");
        String student = scanner.nextLine();
        System.out.print("Enter lecturer name: ");
        String lecturer = scanner.nextLine();
        System.out.print("Enter date (e.g. 10/10/2026): ");
        String date = scanner.nextLine();
        System.out.print("Enter time (e.g. 14:00): ");
        String time = scanner.nextLine();
        System.out.print("Reason for appointment: ");
        String reason = scanner.nextLine();

        Appointment appointment = new Appointment(
                getNextAppointmentId(), student, lecturer, date, time, reason
        );
        system.addAppointment(appointment);

        System.out.println("\nAppointment booked successfully.");
        appointment.displayAppointment();
    }

    private static int getNextConcernId() {
        // For this simple prototype, concern IDs are generated from the current report count.
        // A database version will use database-generated IDs.
        return System.currentTimeMillis() > 0
                ? (int) (System.nanoTime() & 0x7fffffff) : 1;
    }

    private static int getNextAppointmentId() {
        return System.currentTimeMillis() > 0
                ? (int) (System.nanoTime() & 0x7fffffff) : 1;
    }
}
