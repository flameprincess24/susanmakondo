package lectracare;

import java.util.ArrayList;

public class LectraCareSystem {
    private ArrayList<Student> students = new ArrayList<>();
    private ArrayList<Lecturer> lecturers = new ArrayList<>();
    private ArrayList<Concern> concerns = new ArrayList<>();
    private ArrayList<Appointment> appointments = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public void addLecturer(Lecturer lecturer) {
        lecturers.add(lecturer);
    }

    public void addConcern(Concern concern) {
        concerns.add(concern);
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public void displayStudents() {
        System.out.println("\n--- Registered Students ---");
        if (students.isEmpty()) {
            System.out.println("No students registered.");
            return;
        }
        for (Student student : students) {
            System.out.println(student);
        }
    }

    public void displayLecturers() {
        System.out.println("\n--- Registered Lecturers ---");
        if (lecturers.isEmpty()) {
            System.out.println("No lecturers registered.");
            return;
        }
        for (Lecturer lecturer : lecturers) {
            System.out.println(lecturer);
        }
    }

    public void displayConcerns() {
        if (concerns.isEmpty()) {
            System.out.println("\nNo concerns submitted.");
            return;
        }
        for (Concern concern : concerns) {
            concern.displayConcern();
        }
    }

    public void displayAppointments() {
        if (appointments.isEmpty()) {
            System.out.println("\nNo appointments booked.");
            return;
        }
        for (Appointment appointment : appointments) {
            appointment.displayAppointment();
        }
    }

    public void generateReport() {
        int teaching = 0, communication = 0, assessment = 0, attendance = 0, other = 0;

        for (Concern concern : concerns) {
            switch (concern.getCategory()) {
                case "Teaching Method": teaching++; break;
                case "Communication": communication++; break;
                case "Assessment": assessment++; break;
                case "Attendance": attendance++; break;
                default: other++;
            }
        }

        System.out.println("\n==============================");
        System.out.println("       LECTRACARE REPORT");
        System.out.println("==============================");
        System.out.println("Students: " + students.size());
        System.out.println("Lecturers: " + lecturers.size());
        System.out.println("Concerns: " + concerns.size());
        System.out.println("Appointments: " + appointments.size());
        System.out.println("\nConcern categories:");
        System.out.println("Teaching Method: " + teaching);
        System.out.println("Communication: " + communication);
        System.out.println("Assessment: " + assessment);
        System.out.println("Attendance: " + attendance);
        System.out.println("Other: " + other);
        System.out.println("==============================");
    }
}
