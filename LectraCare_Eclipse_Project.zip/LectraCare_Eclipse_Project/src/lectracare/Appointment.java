package lectracare;

public class Appointment {
    private int id;
    private String studentName;
    private String lecturerName;
    private String date;
    private String time;
    private String reason;

    public Appointment(int id, String studentName, String lecturerName,
                       String date, String time, String reason) {
        this.id = id;
        this.studentName = studentName;
        this.lecturerName = lecturerName;
        this.date = date;
        this.time = time;
        this.reason = reason;
    }

    public void displayAppointment() {
        System.out.println("\n--- Appointment " + id + " ---");
        System.out.println("Student: " + studentName);
        System.out.println("Lecturer: " + lecturerName);
        System.out.println("Date: " + date);
        System.out.println("Time: " + time);
        System.out.println("Reason: " + reason);
    }
}
